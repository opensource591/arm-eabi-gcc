/* Generated automatically. */
static const char configuration_arguments[] = "/home/jingyu/projects/gcc/android-toolchainsrc/build/../gcc/gcc-4.4.3/configure --prefix=/usr/local --target=arm-eabi --host=x86_64-linux-gnu --build=x86_64-linux-gnu --with-gnu-as --with-gnu-ld --enable-languages=c,c++ --with-gmp=/home/jingyu/projects/gcc/toolchain_build/obj/temp-install --with-mpfr=/home/jingyu/projects/gcc/toolchain_build/obj/temp-install --disable-libssp --enable-threads --disable-nls --disable-libmudflap --disable-libgomp --disable-libstdc__-v3 --disable-sjlj-exceptions --disable-shared --disable-tls --with-float=soft --with-fpu=vfp --with-arch=armv5te --enable-target-optspace --with-abi=aapcs --with-gcc-version=4.4.3 --with-binutils-version=2.19 --with-gmp-version=4.2.4 --with-mpfr-version=2.4.1 --with-gdb-version=7.1.x --with-arch=armv5te --with-multilib-list=mandroid --with-sysroot=/usr/local/google/home/android/cupcake_rel_root --program-transform-name='s&^&arm-eabi-&'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs" }, { "arch", "armv5te" }, { "float", "soft" }, { "fpu", "vfp" } };
